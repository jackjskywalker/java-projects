// Media class declaration as part of the Library program

package library;
public abstract class Media {

    // Initialize private instance variables
    protected String title;
    protected String publicationDate;

    public Media(String title, String publicationDate) {
        this.title = title;
        this.publicationDate = publicationDate;
    }

    public String getTitle() {
        return title;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public double getCost() {
        return cost;
    }
}
