package library;

public class Magazine extends Media {
    double issueCost;
    int issuesPerYear;

    public Magazine(String title, String publicationDate, double issueCost, int issuesPerYear) {

        super(title, publicationDate);

        this.issueCost = issueCost;

        this.issuesPerYear = issuesPerYear;
    }

    @Override

    public String print() {

        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    }

    @Override

    public double getCost() {

        return issueCost;

    }

}
